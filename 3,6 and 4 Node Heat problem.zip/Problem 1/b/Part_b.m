clc;
clear;


%k=thermal conductivity (W/mK)
k=30;
%qn=heat flux (W/m^2)
q=2e5;
%T1=prescribed temperature at the boundary (Celsius)
T1=200;
%Q=heat generation (W/m^3)
Q2=1e6; Q1=0;
%h=convective heat transfer coefficient (W/m^2K)
h=60;
%Tinf=Surrounding temperature (Celsius)
Tinf=25;

%Coordinate data (x coordinate,y coordinate)
coord=[0.0 0.0;
    0.5 0.0;
    0.0 0.6;
    0.5 0.6;
    0.5 0.3;
    0.8 0.3;
    0.8 0.0;
    0.25 0.0;
    0.25 0.3;
    0.0 0.3;
    0.25 0.6;
    0.5 0.15;
    0.65 0.3;
    0.8 0.15;
    0.65 0.0;
    0.65 0.15];

%Connectivity data
connect=[1 2 3 8 9 10;
    2 4 3 5 11 9;
    2 6 5 16 13 12;
    2 7 6 15 14 16];

%Gauss points for domain integration
xi=[1/3 0.6 0.2 0.2];
eta=[1/3 0.2 0.6 0.2];
w=[-27/48 25/48 25/48 25/48];

%Gauss points for boundary integration
beta=[-sqrt(0.6) sqrt(0.6) 0];
weight=[5/9 5/9 8/9];


%No. of elements
nele=size(connect,1);

%Elemnent stiffness matrix and load vector
Ke=zeros(6,6,nele);
Fe=zeros(6,nele);
coord_e=zeros(6,2);
for ele=1:nele
    %condition for heat generation
    if (ele==1 || ele==2)
        Q=Q1;
    else
        Q=Q2;
    end
    
    % nodes of each element
    node=connect(ele,:);
    % coordinates of each element
    for j=1:length(node)
        coord_e(j,:)=coord(node(j),:);
    end
    coord_e;
    % domain term
    sum_l=zeros(6,6);
    sum_r=zeros(6,1);
    for i=1:length(xi)
        [k_d,f_d]=domain(xi(i),eta(i),coord_e,k,Q);
        sum_l=sum_l+k_d*w(i);
        sum_r=sum_r+f_d*w(i);
    end
    ke_d=sum_l;
    fe_d=sum_r;
    
    %convection term
    sum_l=zeros(6,6); %variable to calculate Gaussian quadrature
    sum_r=zeros(6,1);
    if ele==1
        edgeno=1;
        for j=1:length(beta)
            [k_h,f_h]=gamma_h(beta(j),coord_e,h,Tinf,edgeno);
            sum_l=sum_l+k_h*weight(j);
            sum_r=sum_r+f_h*weight(j);
        end
        ke_h=sum_l;
        fe_h=sum_r;
    end
    
    if ele==2
        edgeno=2;
        for j=1:length(beta)
            [k_h,f_h]=gamma_h(beta(j),coord_e,h,Tinf,edgeno);
            sum_l=sum_l+k_h*weight(j);
            sum_r=sum_r+f_h*weight(j);
        end
        ke_h=sum_l;
        fe_h=sum_r;
    end
    
    if ele==3
        ke_h=zeros(6,6);
        fe_h=zeros(6,1);
    end
    
    if ele==4
        edgeno=1;
        for j=1:length(beta)
            [k_h,f_h]=gamma_h(beta(j),coord_e,h,Tinf,edgeno);
            sum_l=sum_l+k_h*weight(j);
            sum_r=sum_r+f_h*weight(j);
        end
        ke_h=sum_l;
        fe_h=sum_r;
    end
    
    %Heat flux term
    sum_r=zeros(6,1);
    
    if (ele==1 || ele==2)
        fe_q=zeros(6,1);
    end
    if ele==3
        edgeno=2;
        for j=1:length(beta)
            f_q=gamma_q(beta(j),coord_e,q,edgeno);
            sum_r=sum_r+f_q*weight(j);
        end
        fe_q=sum_r;
    end
    
    if ele==4
        edgeno=2;
        for j=1:length(beta)
            f_q=gamma_q(beta(j),coord_e,q,edgeno);
            sum_r=sum_r+f_q*weight(j);
        end
        fe_q=sum_r;
    end
    %Element stiffness matrix
    Ke(:,:,ele)=Ke(:,:,ele)+ke_d+ke_h;
    Fe(:,ele)=Fe(:,ele)+fe_d+fe_h+fe_q;
end


k1=Ke(:,:,1)
k2=Ke(:,:,2)
k3=Ke(:,:,3)
k4=Ke(:,:,4)

f1=Fe(:,1)
f2=Fe(:,2)
f3=Fe(:,3)
f4=Fe(:,4)

% Assembly
K=zeros(16,16);
F=zeros(16,1);
for ele=1:nele
    nd1=connect(ele,1);
    nd2=connect(ele,2);
    nd3=connect(ele,3);
    nd4=connect(ele,4);
    nd5=connect(ele,5);
    nd6=connect(ele,6);
    vec=[nd1 nd2 nd3 nd4 nd5 nd6];
    for i=1:6
        for j=1:6
            K(vec(i),vec(j))=K(vec(i),vec(j))+Ke(i,j,ele);
        end
        F(vec(i))=F(vec(i))+Fe(i,ele);
    end
end

K
F

%Imposition of BC
active=[2 4:9 11:16];
K_reduce=K([2 4:9 11:16],[2 4:9 11:16]);
F_reduce=zeros(13,1);

for i=1:length(active)
    F_reduce(i)=F(active(i))-K(active(i),1)*T1-K(active(i),3)*T1-K(active(i),10)*T1;
end
F_reduce;

%Solution
T_reduce=K_reduce\F_reduce;
T=zeros(16,1);
T(1)=T1; T(3)=T1; T(10)=T1;
T([2 4:9 11:16])=T_reduce;
T
