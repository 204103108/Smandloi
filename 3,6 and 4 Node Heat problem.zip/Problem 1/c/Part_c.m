clc;
clear;

%k=thermal conductivity (W/mK)
k=30;
%qn=heat flux (W/m^2)
qn=2e5;
%T1=prescribed temperature at the boundary (Celsius)
T1=200;
%Q=heat generation (W/m^3)
Q2=1e6; Q1=0;
%h=convective heat transfer coefficient (W/m^2K)
h=60;
%Tinf=Surrounding temperature (Celsius)
Tinf=25;

%Coordinate data (x coordinate,y coordinate)
coord=[0.0 0.0;
    0.5 0.0;
    0.5 0.6;
    0.0 0.6;
    0.5 0.3;
    0.8 0.3;
    0.8 0.0];

%Connectivity data
connect=[1 2 3 4;
    2 7 6 5];

%Gauss points for 3x3 domain integration
xi=[-sqrt(0.6) sqrt(0.6) 0]; 
eta=[-sqrt(0.6) sqrt(0.6) 0]; 
xiw=[5/9 5/9 8/9];
etaw=[5/9 5/9 8/9];

%No. of elements
nele=size(connect,1);
%No. of nodes in each element
nnode=size(connect,2);

%Elemnent stiffness matrix and load vector
%For element 1
coord_1=zeros(nnode,2);
node1=connect(1,:);
for i=1:nnode
    coord_1(i,:)=coord(node1(i),:);
end

%Domain term
sum_l=zeros(nnode,nnode);
sum_r=zeros(nnode,1);
for i=1:length(xi)
    for j=1:length(eta)
        [k1_d,f1_d]=domain(xi(i),eta(j),coord_1,k,Q1);
        sum_l=sum_l+k1_d*xiw(i)*etaw(j);
        sum_r=sum_r+f1_d*xiw(i)*etaw(j);
    end
end
ke1_d=sum_l;
fe1_d=sum_r;

%Convection term
sum_l=zeros(nnode,nnode);
sum_r=zeros(nnode,1);
for i=1:length(xi)
    [k1_h,f1_h]=gamma_h(xi(i),coord_1,h,Tinf,1);
    sum_l=sum_l+k1_h*xiw(i);
    sum_r=sum_r+f1_h*xiw(i);
end
k1_h1=sum_l;
f1_h1=sum_r;

sum_l=zeros(nnode,nnode);
sum_r=zeros(nnode,1);
for i=1:length(xi)
    [k1_h,f1_h]=gamma_h(xi(i),coord_1,h,Tinf,3);
    sum_l=sum_l+k1_h*xiw(i);
    sum_r=sum_r+f1_h*xiw(i);
end
k1_h2=sum_l;
f1_h2=sum_r;

ke1_h=k1_h1+k1_h2;
fe1_h=f1_h1+f1_h2;

ke1=ke1_d+ke1_h;
fe1=fe1_d+fe1_h;

ke1
fe1

%Element 2
%-------------------------
coord_2=zeros(nnode,2);
node2=connect(2,:);
for i=1:nnode
    coord_2(i,:)=coord(node2(i),:);
end

%Domain term
sum_l=zeros(nnode,nnode);
sum_r=zeros(nnode,1);
for i=1:length(xi)
    for j=1:length(eta)
        [k2_d,f2_d]=domain(xi(i),eta(j),coord_2,k,Q2);
        sum_l=sum_l+k2_d*xiw(i)*etaw(j);
        sum_r=sum_r+f2_d*xiw(i)*etaw(j);
    end
end
ke2_d=sum_l;
fe2_d=sum_r;

%Convection term
sum_l=zeros(nnode,nnode);
sum_r=zeros(nnode,1);
for i=1:length(xi)
    [k2_h,f2_h]=gamma_h(xi(i),coord_2,h,Tinf,1);
    sum_l=sum_l+k2_h*xiw(i);
    sum_r=sum_r+f2_h*xiw(i);
end
ke2_h=sum_l;
fe2_h=sum_r;

%Heat flux term
sum_r=zeros(nnode,1);
for i=1:length(xi)
    f2_q=gamma_q(xi(i),coord_2,qn,2);
    sum_r=sum_r+f2_q*xiw(i);
end
f2_q1=sum_r;

sum_r=zeros(nnode,1);
for i=1:length(xi)
    f2_q=gamma_q(xi(i),coord_2,qn,3);
    sum_r=sum_r+f2_q*xiw(i);
end
f2_q2=sum_r;

fe2_q=f2_q1+f2_q2;

ke2=ke2_d+ke2_h;
fe2=fe2_d+fe2_h+fe2_q;

ke2
fe2

% Assembly
K=zeros(7,7);
F=zeros(7,1);
K(1:4,1:4)=K(1:4,1:4)+ke1;
K([2,7,6,5],[2,7,6,5])=K([2,7,6,5],[2,7,6,5])+ke2;

K

F(1:4)=F(1:4)+fe1;
F([2,7,6,5])=F([2,7,6,5])+fe2;

F

%Imposition of BC

active=[2 3 5 6 7];
K_reduce=K([2 3 5 6 7],[2 3 5 6 7]);
F_reduce=zeros(5,1);

for i=1:length(active)
    F_reduce(i)=F(active(i))-K(active(i),1)*T1-K(active(i),4)*T1;
end

%Solution
T_reduce=K_reduce\F_reduce;
T=zeros(7,1);
T(1)=T1; T(4)=T1;
T([2 3 5 6 7])=T_reduce;
T

