%% getting the laminate details

clear 
clc
close all


N = input('Enter the number of plies N ( if it is symmtertic enter N/2 ) \n');     %% number of plies

nn = input('Enter 1 if all the plies are of same material \n');                    

mm = input('Enter 1 if it is a symmetric laminate \n');

p = ply;                                                                           %% object of class ply

it = 1;

fprintf('\n Enter the details of bottom ply first then one after the other plies above it \n');
fprintf(' For eg : If you enter plies like 0,45,-45,90 the laminate is of form [0/45/-45/90] and if you had choosen symmetric it will be [0/45/-45/90/90/-45/45/0] \n\n');
fprintf(' Enter details of plies in the stacking sequence ( if it is symmetric enter details of plies on one side of symmetry \n');

for i=1:N                                                                           %% to getting properties
    
    fprintf('Enter the properties of  ply %d \n',i);                                %% elastic constants
    p(i).E1 = input('E1 (Gpa) ');
    p(i).E2 = input('E2 (Gpa) ');
    p(i).V12 = input('V12  ');
    p(i).t = input('t (mm) ');
    p(i).G12 = input('G12 (Gpa) ');
    p(i).theta = input('theta in degree ');
           
    p(i).S1t = input('Longitudinal tensile strength (Mpa) ');                       %% strength values
    p(i).S1c = input('Longitudinal compressive strength (Mpa) ');
    p(i).S2t = input('Transverse tensile strength (Mpa)  ');
    p(i).S2c = input('Transverse compressive strength (Mpa)  ');
    p(i).tau = input('Shear strength (Mpa)  ');
    
    p(i).a(1,1) = input('Alpha 1  ');                                                   
    p(i).a(2,1) = input('Alpha 2  ');
    p(i).a(3,1) = input('Alpha 12  ');
    p(i).c(1,1) = input('Beta 1  ');
    p(i).c(2,1) = input('Beta 2  ');
    p(i).c(3,1) = input('Beta 12  ');
    
    if nn == 1                                                                      %% if nn=1 laminate is having same properties
        break
    end    
 
end

for i=2:N                                                                           %% using
    fprintf('Enter the properties of  ply %d \n',i);
    p(i) = p(1);
    p(i).theta = input('theta in degree ');
    p(i).t = input(' Thickness in mm ');
end

if mm == 1                                                                          %% if mm=1 implies laminate is symmetric
   p_temp(1,[1:N]) = p(1,[N:-1:1]); 
   p = cat(2,p,p_temp); 
   N = 2*N;
end

fprintf('Enter the loads acting on the laminate (N/mm) \n');

NM = zeros(6,1);

NM(1) = input('Nx ');
NM(2) = input('Ny ');
NM(3) = input('Nxy ');
NM(4) = input('Mx ');
NM(5) = input('My ');
NM(6) = input('Mxy ');

del = input('Enter the temperature difference experienced by the laminate \n');
delc = input('Enter the moisture concentration difference experienced by the laminate \n');

for i=1:N
   p(1,i).delT = del; 
   p(1,i).delC = delc;
end

Nit = N;

z = zeros(N+1,1);                                                                  %% stores the distance of each laminate from mid surface

if rem(N,2) == 0
    
    z((N/2+1),1) = 0;
    
    for i=1:N/2
       z( (N/2 + 1 + i) ,1) =  z( (N/2 + i) ,1) + p( 1,(N/2 + i) ).t;
       z( (N/2 + 1 - i) ,1) =  z( (N/2 + 2 - i) ,1) - p( 1,(N/2 + 1 - i) ).t;
    end
else
    
    z( (N/2 + 0.5),1) = -(p(1,(N/2 + 0.5)).t)*0.5;
    z( (N/2 + 1.5),1) = (p(1,(N/2 + 0.5)).t)*0.5;

    for i=1:N/2
       z( (N/2 + 0.5 - i) ,1) =  z( (N/2 + 1.5 - i) ,1) - (p(1,(N/2 + 0.5 - i)).t);
       z( (N/2 + 1.5 + i) ,1) =  z( (N/2 + 0.5 + i) ,1) + (p(1,(N/2 + 0.5 + i)).t);
    end
    
end

while Nit > 0

    
A = zeros(3);
B = zeros(3);
D = zeros(3);
eps_mid = zeros(3,1);
Kxy_mid = zeros(3,1);

for k=1:N
    
    A = A + p(1,k).Qbar*( z(k+1) - z(k) );
    B = B + p(1,k).Qbar*( power(z(k+1),2) - power(z(k),2) )*0.5;
    D = D + p(1,k).Qbar*(( power(z(k+1),3) - power(z(k),3) )/3);
  
end

ABD = [ A B ; B D ];                                                         %% calculation of ABD matrix
    
temp = ABD\(NM*0.001);

eps_mid([1:3],:) = temp([1:3],:);
Kxy_mid([1:3],:) = temp([4:6],:);

for k=1:N                                                                    %% calculation of stains in each lamina
    if abs(z(k)) > abs(z(k+1)) 
        p(1,k).eps_xy = eps_mid + z(k)*Kxy_mid ;
    else
         p(1,k).eps_xy = eps_mid + z(k+1)*Kxy_mid ;
    end
end
    
if mm == 1                                                                  %% calculation of strength ratio
    SR = zeros(N/2,3);                                                      %% for each lamina SRmax has the maximum strength ratio,tensile or compressive and index of max. SR
    for i=1:N/2
       SR(i,:) = p(1,i).SRmax(1,:);
   end
    
end

SR = zeros(N,3);
for i=1:N
    SR(i,:) = p(1,i).SRmax(1,:);
end
    
tee = SR(:,1);
 M  = max(tee);                                                      %% I has the index of ply with max. SR
 
 j = 0;
 
 for i=1:N
    if M == tee(i)
       j = j+1;
    end
 end
 
I = zeros(1,j); 
 j = 1;
 
 for i=1:N
    if M == tee(i)
       I(j) = i;
       j = j+1;
    end
 end
 
 for i=1:N
    fprintf('\n *************************************************************************************************************\n\n');
    fprintf('\n STRESSES AND STRAIN IN LAMINA NUMBER %d \n',i);
    fprintf('\n RESULTANT STRESSES (only mechanical effects (Mpa) ) \n');
    STRESS = p(1,i).sigma_12 
    fprintf('\n RESULTANT STRAINS (only including mechanical effects ) \n');
    STRAINS =  p(1,i).eps_12
 end
 
 for i=1:size(I,2)
          
fprintf('\n The strength ratio is maximum for lamina number %d having ply angle  %d and is given by %f \n',I(i),p(1,I(i)).theta,M);

 end


for i=1:size(I,2)

fprintf('\n\n  FOR THE %d LAMINA \n ',I(i));    
    
if SR(I(i),3) == 1
    if SR(I(i),2) == 1
        fprintf('\n The mode of failure is longitudinal tensile \n ');
    else
        fprintf('\n The mode of failure is longitudinal compressive \n ');
    end
    
elseif SR(I(i),3) == 2
    if SR(I(i),2) == 1
        fprintf('\n The mode of failure is Transverse  tensile \n ');
    else
        fprintf('\n The mode of failure is transverse compressive \n ');
    end
    
elseif SR(I(i),3) == 3
        fprintf('\n The mode of failure is shear \n ');  
end

end

%% Hygro-thermal effects

NT = zeros(3,1);
MT = zeros(3,1);

NC = zeros(3,1);
MC = zeros(3,1);

for k=1:N
    
   NT = NT + del*( p(1,k).Qbar*p(1,k).axy*( z(k+1) - z(k) ));
   MT = MT + del*0.5*( p(1,k).Qbar*p(1,k).axy*( power(z(k+1),2) - power(z(k),2) ));
   
   NC = NC + delc*( p(1,k).Qbar*p(1,k).cxy*( z(k+1) - z(k) ));
   MC = MC + delc*0.5*( p(1,k).Qbar*p(1,k).cxy*( power(z(k+1),2) - power(z(k),2) ));
  
end

NM_T = [ NT ; MT ];
NM_C = [ NC ; MC ];

temp11 = ABD\(NM_T);
temp22 = ABD\(NM_C);

eps_mid_T([1:3],:) = temp11([1:3],:);
Kxy_mid_T([1:3],:) = temp11([4:6],:);

eps_mid_C([1:3],:) = temp22([1:3],:);
Kxy_mid_C([1:3],:) = temp22([4:6],:);

for k=1:N                                                                    %% calculation of thermal and hygro stains in each lamina
    if abs(z(k)) > abs(z(k+1)) 
        p(1,k).eps_xy_T = eps_mid_T + z(k)*Kxy_mid_T ;
        p(1,k).eps_xy_C = eps_mid_C + z(k)*Kxy_mid_C ;
    else
         p(1,k).eps_xy_T = eps_mid_T + z(k+1)*Kxy_mid_T ;
         p(1,k).eps_xy_C = eps_mid_C + z(k+1)*Kxy_mid_C ;
    end
end

for i=1:size(I,2)

if SR(I(i),3) == 1
    if SR(I(i),2) == 1
        sigma = p(1,I(i)).S1t - p(1,I(i)).sigma_12_R(1);
        R(i) = p(1,I(i)).sigma_12(1)/sigma;
    else
        sigma = -p(1,I(i)).S1c - p(1,I(i)).sigma_12_R(1);
        R(i) = p(1,I(i)).sigma_12(1)/sigma;
    end
    
elseif SR(I(i),3) == 2
    if SR(I(i),2) == 1
        sigma = p(1,I(i)).S2t - p(1,I(i)).sigma_12_R(2);
        R(i) = p(1,I(i)).sigma_12(2)/sigma;
    else
        sigma = -p(1,I(i)).S2c - p(1,I(i)).sigma_12_R(2);
        R(i) = p(1,I(i)).sigma_12(2)/sigma;
    end
    
elseif SR(I(i),3) == 3
        sigma = p(1,I(i)).tau - p(1,I(i)).sigma_12_R(3);
        R(i) = p(1,I(i)).sigma_12(3)/sigma;
end

end

for i=1:size(I,2)

if it == 1
     fprintf('\n THEREFORE THE FIRST PLY FAILURE LOAD CONSIDERING THERMAL AND MECHANICAL LOAD FOR %d LAMINA WILL BE %f \n',I(i),(max(NM)/R(i)) );
else
     fprintf('\n THEREFORE THE %d PLY FAILURE LOAD CONSIDERING THERMAL AND MECHANICAL LOAD FOR %d LAMINA  WILL BE %f \n',it,I(i),(max(NM)/R(i)) );
end

end
fprintf('\n *************************************************************************************************************** \n\n');

for i=1:size(I,2)

    p(1,I(i)).V12 = 0;
    p(1,I(i)).E1 = 0;
    p(1,I(i)).E2 = 0;
    p(1,I(i)).G12 = 0;
    p(1,I(i)).x = 1;

end  

      Nit = Nit - size(I);
      it = it + 1;
end

fprintf('Evaluation of given problem is done \n');
