classdef ply
   properties
       E1
       E2
       V12
       G12
       t
       theta
       S1t
       S1c
       S2t
       S2c
       tau
       a = zeros(3,1)
       axy = zeros(3,1)
       eps_xy = zeros(3,1)
       eps_xy_T = zeros(3,1)
       delT
       delC
       c = zeros(3,1)
       cxy = zeros(3,1)
       eps_xy_C = zeros(3,1)
       x
   end
   
   properties ( Dependent )
       V21
       Q
       Qbar 
       eps_12
       sigma_12
       SR
       SRmax
       sigma_12_R
   end
   
   methods
       function Qn = get.Q(obj)
           
         Qn(1,1) =  obj.E1/( 1-(obj.V12)*(obj.V21) ) ;
         Qn(1,2) =  (obj.V12*obj.E2)/(1-obj.V12*obj.V21);
         Qn(2,1) =  (obj.V12*obj.E2)/(1-obj.V12*obj.V21);
         Qn(2,2) =  obj.E2/( 1-(obj.V12)*(obj.V21) );
         Qn(1,3) = 0;
         Qn(2,3) = 0;
         Qn(3,1) = 0;
         Qn(3,2) = 0;
         Qn(3,3) = obj.G12;
       end
       
       function Qb = get.Qbar(obj)
           
         Qb(1,1) = obj.Q(1,1)*power(cosd(obj.theta),4) + 2*(obj.Q(1,2) + 2*obj.Q(3,3))*power(sind(obj.theta),2)*power(cosd(obj.theta),2) + obj.Q(2,2)*power(sind(obj.theta),4);
         
         Qb(2,2) = obj.Q(1,1)*power(sind(obj.theta),4) + 2*( obj.Q(1,2) + 2*obj.Q(3,3) )*power(sind(obj.theta),2)*power(cosd(obj.theta),2) + obj.Q(2,2)*power(cosd(obj.theta),4);
         
         Qb(1,2) = (obj.Q(1,1) + obj.Q(2,2) - 4*obj.Q(3,3))*power(sind(obj.theta),2)*power(cosd(obj.theta),2) + obj.Q(1,2)*( power(sind(obj.theta),4) + power(cosd(obj.theta),4) );
         
         Qb(3,3) = (obj.Q(1,1) + obj.Q(2,2) - 2*obj.Q(3,3) - 2*obj.Q(1,2))*power(sind(obj.theta),2)*power(cosd(obj.theta),2) + obj.Q(3,3)*(power(sind(obj.theta),4) + power(cosd(obj.theta),4));
         
         Qb(2,3) = (obj.Q(1,1) - obj.Q(1,2) - 2*obj.Q(3,3))*cosd(obj.theta)*power(sind(obj.theta),3) + (obj.Q(1,2) - obj.Q(2,2) + 2*obj.Q(3,3))*sind(obj.theta)*power(cosd(obj.theta),3);
         
         Qb(1,3) = (obj.Q(1,1) - obj.Q(1,2) - 2*obj.Q(3,3))*sind(obj.theta)*power(cosd(obj.theta),3) + (obj.Q(1,2) - obj.Q(2,2) + 2*obj.Q(3,3))*cosd(obj.theta)*power(sind(obj.theta),3);
         
         Qb(2,1) = (obj.Q(1,1) + obj.Q(2,2) - 4*obj.Q(3,3))*power(sind(obj.theta),2)*power(cosd(obj.theta),2) + obj.Q(1,2)*(power(sind(obj.theta),4) + power(cosd(obj.theta),4));
         
         Qb(3,1) = (obj.Q(1,1) - obj.Q(1,2) - 2*obj.Q(3,3))*sind(obj.theta)*power(cosd(obj.theta),3) + (obj.Q(1,2) - obj.Q(2,2) + 2*obj.Q(3,3))*cosd(obj.theta)*power(sind(obj.theta),3);
         
         Qb(3,2) = (obj.Q(1,1) - obj.Q(1,2) - 2*obj.Q(3,3))*cosd(obj.theta)*power(sind(obj.theta),3) + (obj.Q(1,2) - obj.Q(2,2) + 2*obj.Q(3,3))*sind(obj.theta)*power(cosd(obj.theta),3);
       end
       
       function V = get.V21(obj)
         if obj.E1 ~= 0
           V = obj.E2*obj.V12/obj.E1;
         else
           V = 0;
         end
       end
       
       function e = get.eps_12(obj)
          
           T = [ power(cosd(obj.theta),2)  power(sind(obj.theta),2) -2*sind(obj.theta)*cosd(obj.theta) ; power(sind(obj.theta),2)  power(cosd(obj.theta),2)  2*sind(obj.theta)*cosd(obj.theta) ; sind(obj.theta)*cosd(obj.theta)  -1*sind(obj.theta)*cosd(obj.theta)   power(cosd(obj.theta),2) - power(sind(obj.theta),2) ]; 
           e = obj.eps_xy;
           e(3,1) = e(3,1)*0.5;
           e = T\e;
           e(3,1) = e(3,1)*2;
       end
       
       function s = get.sigma_12(obj)
           s = obj.Q*obj.eps_12;
           s = s*1000;
       end
       
       function s = get.SR(obj)
           
             if obj.sigma_12(1) < 0
                 s(1,1) = abs(obj.sigma_12(1))/obj.S1c;
                 s(1,2) = -1;
             else
                 s(1,1) = obj.sigma_12(1)/obj.S1t;
                 s(1,2) = 1;
             end
             
             if obj.sigma_12(2) < 0
                 s(2,1) = abs(obj.sigma_12(2))/obj.S2c;
                 s(2,2) = -1;
             else
                 s(2,1) = obj.sigma_12(2)/obj.S2t;
                 s(2,2) = 1;
             end
             
             s(3,1) = obj.sigma_12(3)/obj.tau;
             s(3,2) = 1;
       end
          
       
       function s = get.SRmax(obj)
           
           if obj.x == 1
               s = 0;
           else
                tee = obj.SR(:,1);
                [ M , I ] = max(tee);
          
                s(1,:) = [obj.SR(I,:) , I];
           end
       end
       
       function ax = get.axy(obj)
           T = [ power(cosd(obj.theta),2)  power(sind(obj.theta),2) -2*sind(obj.theta)*cosd(obj.theta) ; power(sind(obj.theta),2)  power(cosd(obj.theta),2)  2*sind(obj.theta)*cosd(obj.theta) ; sind(obj.theta)*cosd(obj.theta)  -1*sind(obj.theta)*cosd(obj.theta)   power(cosd(obj.theta),2) - power(sind(obj.theta),2) ]; 
           ax = T*obj.a;
           ax(3,1) = 2*ax(3,1);
       end
       
       function cx = get.cxy(obj)
           T = [ power(cosd(obj.theta),2)  power(sind(obj.theta),2) -2*sind(obj.theta)*cosd(obj.theta) ; power(sind(obj.theta),2)  power(cosd(obj.theta),2)  2*sind(obj.theta)*cosd(obj.theta) ; sind(obj.theta)*cosd(obj.theta)  -1*sind(obj.theta)*cosd(obj.theta)   power(cosd(obj.theta),2) - power(sind(obj.theta),2) ]; 
           cx = T*obj.c;
           cx(3,1) = 2*cx(3,1);
       end
       
       function s = get.sigma_12_R(obj)
           eR = obj.eps_xy_T - obj.delT*obj.axy;
           cR = obj.eps_xy_C - obj.delC*obj.cxy;
           sR = obj.Qbar*eR;
           sC = obj.Qbar*cR;
            T = [ power(cosd(obj.theta),2)  power(sind(obj.theta),2) -2*sind(obj.theta)*cosd(obj.theta) ; power(sind(obj.theta),2)  power(cosd(obj.theta),2)  2*sind(obj.theta)*cosd(obj.theta) ; sind(obj.theta)*cosd(obj.theta)  -1*sind(obj.theta)*cosd(obj.theta)   power(cosd(obj.theta),2) - power(sind(obj.theta),2) ]; 
           s1 = T\sR;
           s2 = T\sC;
           s = s1 + s2;
           s = s*1000;
       end

       
   end

end    